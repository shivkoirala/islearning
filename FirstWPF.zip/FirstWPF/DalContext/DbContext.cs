﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerModel;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using RepositoryInterfaces;
namespace DalContext
{
    public class DbContextEf<T> :  IRepository<T>
         where T : AbstractEntity
    {
        private DbContext _DbContext = null;
        public DbContextEf()
        {
            // hack... there is some problem
            var instance = System.Data.Entity.SqlServer.SqlProviderServices.Instance;
            _DbContext = new
                CustomerEfContext(@"Data Source=DESKTOP-TVS0VQT\SQLEXPRESS;Initial Catalog=CustomerDbJP;Integrated Security=True");

        }
        public void Add(T entity)
        {
            _DbContext.Set<T>().Add(entity);
        }

        public void Save()
        {
            _DbContext.SaveChanges();
        }

        public IQueryable<T> Search()
        {
            return _DbContext.Set<T>().AsQueryable<T>();
        }

        public void SetUow(IUow u)
        {
            this._DbContext = ((EfUow)u)._DbContext;
        }
    }
    public class EfUow : IUow
    {
        public DbContext _DbContext = null;
        private DbContextTransaction _DbTrans = null;
        public EfUow()
        {
            _DbContext = new
                CustomerEfContext(@"Data Source=DESKTOP-TVS0VQT\SQLEXPRESS;Initial Catalog=CustomerDbJP;Integrated Security=True");
        }
        public void Begin()
        {
           _DbTrans =  _DbContext.Database.BeginTransaction();
            
        }
        public void Committ()
        {
            this._DbTrans.Commit();
        }

        public void RollBack()
        {
            this._DbTrans.Rollback();
        }
    }
    public class CustomerEfContext : DbContext
    {
        public CustomerEfContext(string conn) : base(conn)
        {
            // maping 
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Address>().ToTable("tblAddress");
            modelBuilder.Entity<Address>().Property(e => e.Id).
              HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            modelBuilder.Entity<Customer>().ToTable("tblCustomer");
            modelBuilder.Entity<Customer>().Property(e => e.Id).
                HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

        }
    }
    //public class DbCustomerContextAdo
    //{
    //    List<Customer> custs = new List<Customer>();
    //    public void Save(Customer obj)
    //    {
    //        // Connection object say where you sql
    //        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-TVS0VQT\SQLEXPRESS;Initial Catalog=CustomerDbJP;Integrated Security=True");
    //        conn.Open();
    //        // Command object
    //        SqlCommand comm = new SqlCommand();
    //        comm.CommandText = "insert into [tblCustomer] values(" + obj.CustomerId 
    //                            + ",'" + obj.CustomerName + "',"+ obj.CustomerAmount +")";
    //        // Command object will sent over which
    //        comm.Connection = conn;
    //        // execute
    //        comm.ExecuteNonQuery();
    //        // close connection
    //        conn.Close();
    //    }
    //    public IEnumerable<Customer> GetCustomers()
    //    {
    //        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-TVS0VQT\SQLEXPRESS;Initial Catalog=CustomerDbJP;Integrated Security=True");
    //        conn.Open();
    //        // Command object
    //        SqlCommand comm = new SqlCommand();
    //        comm.CommandText = "select * from tblCustomer";
    //        // Command object will sent over which
    //        comm.Connection = conn;
    //        SqlDataReader dr = comm.ExecuteReader();
            
    //        while (dr.Read())
    //        {
    //            Customer obj = new Customer();
    //            obj.CustomerId = Convert.ToInt16(dr["CustomerId"]);
    //            obj.CustomerAmount = Convert.ToDecimal(dr["CustomerAmount"]);
    //            obj.CustomerName = Convert.ToString(dr["CustomerName"]);
    //            custs.Add(obj);
    //        }
    //        return custs;
    //    }
    //}
}
