﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FirstWPF
{
    /// <summary>
    /// Interaction logic for Threading.xaml
    /// </summary>
    public partial class Threading : Window
    {
        public Threading()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Task x = new Task(SetText);
            x.Start();
        }
        public void SetText()
        {
          this.Dispatcher.Invoke(()=>txt1.Text = "Shiv");
        }
    }
}
