﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerModel
{
    public interface IEntity
    {
         int Id { get; set; }
    }
    public abstract class AbstractEntity : IEntity
    {
        [Key]
        public virtual int Id { get; set; }
    }
    public class Customer : AbstractEntity
    {
       

        public decimal CustomerAmount { get; set; }
        private string _CustomerName;

        public string CustomerName
        {
            get {
                return _CustomerName;
            }
            set {
                _CustomerName = value;
            }
        }
       

    }

    public class Address : AbstractEntity
    {
        public string AddressName { get; set; }
    }
}
