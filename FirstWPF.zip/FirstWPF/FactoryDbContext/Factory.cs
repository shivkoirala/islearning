﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RepositoryInterfaces;
using Unity;
using DalContext;
using CustomerModel;
namespace FactoryDbContext
{
    public static class FactoryDbContextClass<T>
        where T : AbstractEntity
    {
        static IUnityContainer repository = new UnityContainer();
        static FactoryDbContextClass()
        {
            
            repository.RegisterType<IRepository<T>,
                DbContextEf<T>>("Ef");


        }
        public static IRepository<T> Create(string str)
        {
            return repository.Resolve<IRepository<T>>(str);
        }
    }
    public static class FactoryUow
    {
        static IUnityContainer UowContainer = new UnityContainer();
        static FactoryUow()
        {
            UowContainer.RegisterType<IUow,EfUow>("EfUow");
        }
        public static IUow Create(string str)
        {
            return UowContainer.Resolve<IUow>(str);
        }
    }

}
