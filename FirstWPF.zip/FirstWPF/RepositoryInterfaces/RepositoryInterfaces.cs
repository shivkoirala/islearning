﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryInterfaces
{
    public interface IRepository<T>
    {
        void Add(T entity); // in memory
        void Save(); // physical commit
        IQueryable<T> Search();
        void SetUow(IUow u);
    }
    public interface IUow
    {
        void Begin();
        void Committ();
        void RollBack();
    }
}
