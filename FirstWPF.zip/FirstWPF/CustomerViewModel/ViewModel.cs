﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using CustomerModel;
using FactoryDbContext;
using RepositoryInterfaces;

namespace CustomerViewModel
{
    public class CustomerVM : INotifyPropertyChanged
    {
        public ICommand SaveCommand = null;
        public Customer CustomerObj { get; set; }
        public IEnumerable<Customer> Customers { get
            {
                IUow uow = FactoryUow.Create("EfUow");
                IRepository<Customer> repo = FactoryDbContextClass<Customer>.Create("Ef");
                repo.SetUow(uow);

                return repo.Search().ToList<Customer>();
            }
        }
        public void Save()
        {
            IUow uow = FactoryUow.Create("EfUow");
            uow.Begin();
            IRepository<Customer> repo = FactoryDbContextClass<Customer>.Create("Ef");
            repo.SetUow(uow);
            IRepository<Address> repo1 = FactoryDbContextClass<Address>.Create("Ef");
            repo1.SetUow(uow);


            repo.Add(this.CustomerObj);
            repo.Save();
            repo1.Add(new Address() { Id=1,AddressName="Banglore" });
            repo1.Save();

            uow.Committ();
            PropertyChanged(this,
                    new PropertyChangedEventArgs("Customers"));
        }
        public ICommand SaveCommandClick { get
        {
            return SaveCommand;
        }
        }
        public bool IsValid()
        {
            
            return true;
        }
        public CustomerVM()
        {
            SaveCommand = new SaveCommand(this.Save, this.IsValid);
            this.CustomerObj = new Customer();
            this.LabelColor = "Yellow";
        }
      
        public decimal CustomerAmount
        {
            get { return CustomerObj.CustomerAmount; }
            set {
                CustomerObj.CustomerAmount = value;
                if(value > 100)
                {
                    LabelColor = "Red";
                }
                else
                {
                    LabelColor = "Blue";
                }
                PropertyChanged(this, 
                    new PropertyChangedEventArgs("LabelColor"));
            }
        }

        public string LabelColor { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        
    }

    public class SaveCommand : ICommand
    {
        Func<bool> _CanExecute = null;
        Action _Execute = null;
        public event EventHandler CanExecuteChanged;
        public SaveCommand(Action execute , Func<bool> canexecute)
        {
            _CanExecute = canexecute;
            _Execute = execute;
        }
        public bool CanExecute(object parameter)
        {
            // Can the below Execute -- validation
            return _CanExecute();
        }

        public void Execute(object parameter)
        {
            _Execute();
        }
    }
}
